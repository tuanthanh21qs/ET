<?php
// load the parent index.php file
 
require_once( get_template_directory() . '/index.php' );
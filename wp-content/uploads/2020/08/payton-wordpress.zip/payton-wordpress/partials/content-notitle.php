<?php
/**
 * This partial is used for displaying notitle
 *
 * @package Layers
 * @since Layers 1.0.0
 */

	the_content(); ?>

 